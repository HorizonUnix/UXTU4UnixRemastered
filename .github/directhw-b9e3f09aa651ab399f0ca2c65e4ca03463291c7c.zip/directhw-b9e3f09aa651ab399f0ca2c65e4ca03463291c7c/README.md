Direct Hardware driver and library for Mac OS X 10.4 to macOS 13.

Consists of 2 parts:
- The user space library
- The kernel space driver
